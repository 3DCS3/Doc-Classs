package deckOfShuffledCards;

import javax.swing.*;

public class theShuffledDeck
{
	public theShuffledDeck()
	{
		String[] theDeck = null;
		String[] theShuffledDeck = null;

		theDeck = oneDeck(theDeck);
		showDeck(theDeck);

		theShuffledDeck = shuffledDeck(theDeck, theShuffledDeck);
		showDeck(theShuffledDeck);
	}

	public String[] oneDeck(String[] theDeck)
	{
		theDeck = initializeDeck(theDeck);

		theDeck = assignPictures(theDeck);

		theDeck = assignSuits(theDeck);

		return theDeck;
	}

	public String[] initializeDeck(String[] theDeck)
	{
		theDeck = new String[52];
		for (int n = 0, m = 1; n < theDeck.length; n++, m++)
		{
			if (m == 14)
			{
				m = 1;
			}
			theDeck[n] = String.valueOf(m);

		}

		return theDeck;

	}

	public String[] assignPictures(String[] theDeck)
	{
		for (int n = 0; n < theDeck.length; n++)
		{
			switch (Integer.parseInt(theDeck[n]))
			{
			case 1:
				theDeck[n] = "ace";
				break;
			case 11:
				theDeck[n] = "jack";
				break;
			case 12:
				theDeck[n] = "queen";
				break;
			case 13:
				theDeck[n] = "king";
				break;
			default:
				theDeck[n] = String.valueOf(Integer.parseInt(theDeck[n]));
				break;
			}

		}
		return theDeck;
	}

	public String[] assignSuits(String[] theDeck)
	{
		for (int n = 0; n < theDeck.length; n++)
		{
			switch (n / 13)
			{
			case 0:
				theDeck[n] += " clubs";
				break;
			case 1:
				theDeck[n] += " diamonds";
				break;
			case 2:
				theDeck[n] += " hearts";
				break;
			default:
				theDeck[n] += " spades";
				break;
			}
		}

		return theDeck;
	}

	public void showDeck(String[] theDeck)
	{
		{
			String outputString = "";

			for (int n = 0; n < theDeck.length; n++)
			{
				if (n % 13 == 0)
				{
					outputString += "\n";
				}

				outputString += theDeck[n] + ", ";
			}

			JOptionPane.showMessageDialog(null, outputString);
		}
	}

	public int obtainRandomNumber(int maxValue)
	{
		double n;

		n = Math.random();

		n *= 1000000;

		return (int) n % maxValue;
	}

	public String[] intializeShuffleTheDeck(String[] theDeck)
	{
		String[] shuffledDeck = new String[theDeck.length];

		return shuffledDeck;
	}

	public String[] makeDisposableDeck(String[] theDeck)
	{
		String[] disposableDeck = new String[theDeck.length];

		for (int n = 0; n < theDeck.length; n++)
		{
			disposableDeck[n] = theDeck[n];
		}

		return disposableDeck;
	}

	public String[] shuffledDeck(String[] theDeck, String[] theShuffledDeck)
	{
		int eleNum;

		theShuffledDeck = intializeShuffleTheDeck(theDeck);

		String[] disposableDeck = null;
		disposableDeck = makeDisposableDeck(theDeck);

		// loop through the deck randomly moving cards to the shuffled deck
		for (int n = 0; n < theDeck.length; n++)
		{
			eleNum = obtainRandomNumber(disposableDeck.length);

			while (disposableDeck[eleNum].equalsIgnoreCase("-1"))
			{
				eleNum++;
				if (eleNum == disposableDeck.length)
				{
					eleNum = 0;
				}
			}

			theShuffledDeck[n] = disposableDeck[eleNum];
			disposableDeck[eleNum] = "-1";
		}

		return theShuffledDeck;
	}

}
